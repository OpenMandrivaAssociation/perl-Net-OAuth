package Net::OAuth::SignatureMethod::PLAINTEXT;

use warnings;
use strict;

use base 'Net::OAuth::SignatureMethod';

sub sign {
    my $self = shift;
    my $request = shift;
    return $request->signature_key;
}

sub verify {
    my $self = shift;
    my $request = shift;
    return $self->secure_compare( $request->signature, $self->sign($request) );
}

=head1 NAME

Net::OAuth::SignatureMethod::PLAINTEXT - PLAINTEXT Signature Method for OAuth protocol

=head1 SEE ALSO

L<Net::OAuth>, L<http://oauth.net>

=head1 AUTHOR

Originally by Keith Grennan <foss@nearlyfree.org>

Currently maintained by Robert Rothenberg <perl@rhizomnic.com>

=head1 COPYRIGHT & LICENSE

Copyright 2007-2012, 2024-2026 Keith Grennan

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut

1;
